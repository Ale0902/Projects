import iTunes_Scrape
import csv

def topsongs():
        iTunes_Scrape.updateSongList()
        with open('F:\VS Projects\Discord_Bot\Top_Songs.csv') as csvfile:
            csv_reader = csv.reader(csvfile, delimiter=',')
            count = 0
            song_name =[]
            artist =[]
            rank =[]

            for row in csv_reader:
                if count == 0:
                    headers = row[0], ' ', row[1], ' ', row[2]
                else:
                    song_name.append(row[0])
                    artist.append(row[1])
                    rank.append(row[2])
                count += 1
                if(count > 5):
                    break   

        return song_name, artist, rank