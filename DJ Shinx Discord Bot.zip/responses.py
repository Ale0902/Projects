import random
import discord

def getResponse(message):
    p_message = message.lower()
    try:
        if(p_message == 'hello'):
            return 'hi'
        
        if(message == 'hh.roll'):
            number = str(random.randint(1,6))
            return (f'You rolled a {number}!')
        
        if(p_message == 'hh.help'):
            return '`I play ping pong,\nI respond hi if you say hello\nI roll a die for you if you say hh.roll\nI can show you the current top 5 iTunes songs with hh.topsongs`'
        
        if(p_message == 'ping'):
            return 'PONG!'
        
    except:
        pass