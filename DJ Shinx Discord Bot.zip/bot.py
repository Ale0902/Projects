import discord
import responses
import botFunctions

TOKEN = 'TE2NzY0MDU5MzUwNjI1ODk5NA.GpB_9c.JBcMfuWsCIWNJoGr1FpgPVt68VvBNkBpPkVStg'

async def sendMessage(message, user_message, is_private):
    try:
        response = responses.getResponse(user_message)
        await message.author.send(response) if is_private else await message.channel.send(response)
    
    except Exception as e:
        print(e)


async def sendTopSongs(message):
    songs, artist, rank = botFunctions.topsongs()
    await message.channel.send("The top 5 songs on iTunes right now!")
    for i in range(5):
        await message.channel.send('**Rank: ' + f'{rank[i]}**' +'\n'+ f'*"{songs[i]}"*' + ', ' + f'{artist[i]}')
    await message.channel.send('Source: https://www.popvortex.com/music/charts/top-100-songs.php')



def run_discord_bot():
    TOKEN = 'MTE2NzY0MDU5MzUwNjI1ODk5NA.GpB_9c.JBcMfuWsCIWNJoGr1FpgPVt68VvBNkBpPkVStg'
    intents = discord.Intents.default()
    intents.message_content = True
    client = discord.Client(intents=intents)

    @client.event
    async def on_ready():
        print(f'{client.user} is now running!')

    @client.event
    async def on_message(message):
        if message.author == client.user:
            return
        
        username = str(message.author)
        user_message = str(message.content)
        channel = str(message.channel)

        print(f'{username} said: {user_message}', ({channel}))

        if(user_message =='hh.help'):
            await sendMessage(message, user_message, is_private = True)
        else:
            await sendMessage(message, user_message, is_private = False)

        if(user_message.lower() == 'hh.topsongs'):
            await sendTopSongs(message)

    client.run(TOKEN)
        

        

