# imports for web scraping 
import requests
from bs4 import BeautifulSoup
import csv

# getting the page information
page = requests.get('https://github.com/trending')
soup = BeautifulSoup(page.text, 'html.parser')

# finding the HTML div we want to work with
box_ = soup.find(class_="Box")
boxes = soup.find_all(class_ = "Box-row")

# setting up CSV file
fileName = 'github_trending_today.csv'
f = csv.writer(open(fileName, 'w', newline =''))
f.writerow(['Developer', 'Repo Name', 'Number of Stars'])

for box in boxes:
    # Extracting the dev name, repository name, and how many stars it has from the github page
    full_repo_name = box.find(class_="h3 lh-condensed").text.split('/')
    developer = (full_repo_name[0].split())
    repo_name = full_repo_name[1].split()
    stars = box.find(class_="d-inline-block float-sm-right").text.split()

    # Writing information to CSV file
    f.writerow([''.join(developer), ''.join(repo_name), ''.join(stars[0])])
    #print('developer:', ''.join(developer), 'Repository name:', ''.join(repo_name), 'stars:', ''.join(stars[0]), '\n')

